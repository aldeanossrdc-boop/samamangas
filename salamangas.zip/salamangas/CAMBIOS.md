# SalaMangaS — revisión del 14/10/2026

## Cómo instalarlo (estructura del repo)
```
/index.html                      ← corregido
/sala-ceo.html                   ← igual que el tuyo (sin cambios)
/service-worker.js               ← corregido (va SUELTO en la raíz, no dentro de un zip)
/manifest.json                   ← NUEVO (index.html lo pedía y no existía)
/package.json                    ← NUEVO (Cloudflare lo necesita para @supabase/supabase-js)
/functions/api/_filtro.js        ← corregido
/functions/api/_ia.js            ← corregido
/functions/api/_deepinfra.js     ← corregido
/functions/api/ia-generar.js     ← corregido
/functions/api/asistente.js      ← corregido
/functions/api/_shared.js        ← sin cambios
/functions/api/ia-personaje.js   ← sin cambios
/functions/api/ia-estado.js      ← NUEVO (el front lo llama y no existía)
/functions/api/ia-imagen.js      ← NUEVO (el front lo llama y no existía)
/functions/api/_leonardo.js      ← NUEVO, pero SOLO si no lo tenés (ver abajo)
/functions/api/push/public-key.js← NUEVO
/functions/api/push/suscribir.js ← NUEVO
/sql/push_subscriptions.sql      ← correrlo en Supabase (solo para notificaciones push)
```

## Qué estaba mal y qué hice
1. **Faltaba `_leonardo.js`**: `_ia.js` lo importa (`CEO_EMAILS`). Sin él, TODAS las funciones de IA y el asistente se caen al arrancar. Si ya lo tenés en tu repo, no lo pises: solo verificá que exporte `CEO_EMAILS`.
2. **Faltaban `/api/ia-estado` y `/api/ia-imagen`**: el front los usa para el modo Lápiz (Leonardo) — esperar el resultado y mostrar/descargar la imagen. Sin ellos Lápiz nunca terminaba. Creados (`ia-imagen` solo acepta imágenes https de leonardo.ai).
3. **Filtro**: el CEO estaba exento hasta del bloqueo de contenido sexual con menores, aunque el comentario decía "bloqueo siempre". Ahora ese bloqueo aplica a todos, CEO incluido.
4. **IA generaba 2 imágenes y mostraba 1**: el front pide UNA imagen (`slice(0,1)`), pero el servidor generaba 2 → pagabas el doble. Ahora genera 1. Texto del asistente de ayuda actualizado.
5. **FLUX Kontext (opción del panel CEO `ia_modelo_escena`)** es un modelo de *edición* (exige imagen de entrada); en texto→imagen falla. Si el CEO lo elegía, SalaMangaS IA se rompía. Ahora, sin imagen, usa Qwen-Image automáticamente.
6. **Clasificación de errores de DeepInfra**: el texto "content" (aparece en muchos errores) se tomaba como "contenido no permitido", y un 401/403 de clave mala podía mostrarse mal. Reordenado y ajustado.
7. **`index.html`**: el botón "Recarga IA" llamaba a `abrirRecargaIA()`, que no existía (error JS). Definida; abre la pestaña Sakuras IA.
8. **Service worker**: el ícono de las notificaciones era `/logo.png` y la app usa `/logo.jpg`. Corregido y subida la versión (`2026.10.14.2`). Estaba dentro de un zip: tiene que estar suelto en la raíz para que funcione en `/service-worker.js`.
9. **Push**: el front pedía `/api/push/public-key` y `/api/push/suscribir`, que no existían. Creados (guardan la suscripción con RLS).

## Variables de entorno en Cloudflare (revisá que estén)
`SUPABASE_SERVICE_ROLE_KEY`, `LEONARDO_API_KEY`, `DEEPINFRA_API_KEY`, `PAYPAL_CLIENT_ID`, `PAYPAL_SECRET`, `PAYPAL_MODE`, y para push `VAPID_PUBLIC_KEY`. Opcionales: `DI_MODELO_CHAT` (DeepInfra ya publicó `deepseek-ai/DeepSeek-V4-Flash-0731`, la versión oficial que reemplaza a la preview), `DI_MODELO_PERSONAJE`, `DI_MODELO_QWEN`, `DI_MODELO_EDIT`.

## Lo que NO pude revisar / pendiente
- **Pagos**: el front llama `mercadopago-create-preference`, `paypal-create-order` y `paypal-create-subscription` (y habrá webhooks). No me llegaron esos archivos: mandámelos y los reviso. No los reescribí a ciegas porque manejan plata.
- **Push**: quedó lista la suscripción, pero falta el envío de notificaciones (VAPID privada + librería de envío). No existe en lo que subiste.
- **Funciones SQL de Supabase** que el servidor usa: `usar_generacion_ia`, `devolver_generacion_ia`, `asistente_acceso`, `puede_generar_personaje` (y el front usa `consumir_personaje_ia`, `devolver_personaje_ia`, `estado_personajes_ia`). Verificá que existan. Ojo: si `devolver_*` se puede llamar repetido desde el navegador, alguien podría regalarse generaciones; que solo devuelva si hubo un cobro previo.
- Si una generación de Leonardo falla *después* de crearse (ya cobrada), no se devuelve sola. Es un caso raro; se puede automatizar guardando el id.
- Íconos PWA: `manifest.json` usa `/logo.jpg`. Para que se pueda instalar bien en todos los celulares conviene sumar PNG de 192 y 512.
- `index.html` trae código viejo del panel CEO que ya no usa (el panel vive en `sala-ceo.html`); no molesta, pero se puede limpiar. Los ids `creGrid`/`subsLista` están repetidos en plantillas distintas, sin efecto real.

---
# Ronda 2 — pagos y devolución de generaciones

## Archivos nuevos / reemplazados
- NUEVO `functions/api/_pagos.js` (helpers de pagos)
- REEMPLAZAR `mercadopago-webhook.js`, `paypal-webhook.js`, `paypal-create-order.js` (subilo SIN el `__1_` en el nombre), `mercadopago-create-preference.js`, `paypal-create-subscription.js`
- REEMPLAZAR `ia-generar.js`, `ia-estado.js` (devolución automática si Leonardo falla)
- SQL a correr en Supabase: `sql/pagos_procesados.sql` y `sql/ia_generaciones.sql`
- `_notificar-pago.js` y `_leonardo.js`: NO se tocan (los tuyos quedan como están)

## Bugs de plata corregidos
1. Los webhooks acreditaban el pago cada vez que el proveedor reenviaba el aviso (pasa seguido): sakuras y donaciones duplicadas. Ahora cada pago se acredita una sola vez.
2. Planes: la activación y el primer cobro llegaban juntos y sumaban 2 meses y 2×200 Sakuras. Ahora es un mes por usuario+plan+mes.
3. Si fallaba un rpc/insert en la base, el pago se perdía en silencio (se respondía 200). Ahora se revisa y se responde 500 para que el proveedor reintente.
4. PayPal: si la captura ya estaba hecha (reintento), no acreditaba. Corregido.
5. `paypal-create-order` decidía sandbox/live al revés que el resto (sin `PAYPAL_MODE`, la orden iba a sandbox y la suscripción a live). Ahora todo usa `_shared.js`. Poné `PAYPAL_MODE` explícito.
6. Un `item` como "constructor" pasaba la validación de precios. Corregido.
7. `paypal-webhook` sin `PAYPAL_WEBHOOK_ID` fallaba en silencio; ahora lo dice en el log.
8. `_notificar-pago.js` nunca se llamaba: ahora los webhooks avisan al usuario y al CEO.

## Para que decidas vos
- Reparto de donaciones: PayPal da 20% al creador Pro, 50% Súper Pro y 0% al resto; Mercado Pago da 50% a Pro/Súper Pro y 20% al resto. Son opuestos. No lo toqué. Además Semi Dios y Dios no están contemplados en ninguno.
- PayPal baja al usuario a Gratis apenas falla UN pago (PayPal reintenta solo) y al cancelar, aunque ya haya pagado el mes.
- `paypal-create-subscription` crea un producto y un plan nuevos en PayPal en cada clic.
- No hay manejo de reembolsos/contracargos.

---
# Ronda 3 — íconos, IA, legales
- Íconos PWA generados desde tu logo: `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png` (manifest, index.html y service worker actualizados, SW v2026.10.14.3).
- `logo.jpg` pesaba 1,9 MB y se carga en el login y la portada: ahora es una versión de 512 px (112 KB). Reemplazá el tuyo por este.
- `ia-estado.js`: se fusionó con el tuyo (mantiene tu validación UUID). Ahora devuelve la generación solo una vez y solo si el usuario la pagó. Si la tabla `ia_generaciones` todavía no existe, se comporta como el tuyo de antes.
- `ia-imagen.js`: versión más estricta (sin redirecciones, solo imágenes, máx. 15 MB).
- `_leonardo.js`: NO incluido (usá el tuyo, es correcto).
- `terminos.html` y `privacidad.html`: actualizados (IA, pagos, notificaciones, Muro). Revisalos vos; no soy abogado.
- `sql/extraer_funciones.sql`: consulta de solo lectura para que me pases las funciones de Supabase.
